package app.peel.stickers;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Keeps exported packs on disk so the content provider can serve them to WhatsApp. */
final class StickerStore {
    private StickerStore() {}

    static String safe(String id) {
        String s = id == null ? "" : id.replaceAll("[^A-Za-z0-9_-]", "_");
        if (s.isEmpty()) s = "pack";
        return s.length() > 60 ? s.substring(0, 60) : s;
    }

    static File root(Context c) {
        File f = new File(c.getFilesDir(), "packs");
        //noinspection ResultOfMethodCallIgnored
        f.mkdirs();
        return f;
    }

    static File dir(Context c, String id) {
        return new File(root(c), safe(id));
    }

    static List<String> ids(Context c) {
        List<String> out = new ArrayList<>();
        File[] fs = root(c).listFiles();
        if (fs != null) for (File f : fs) if (f.isDirectory() && new File(f, "meta.json").exists()) out.add(f.getName());
        return out;
    }

    static synchronized void begin(Context c, String id, String name, String author, byte[] tray, boolean animated)
            throws Exception {
        File d = dir(c, id);
        deleteRecursive(d);
        if (!d.mkdirs()) throw new IOException("Can't create pack folder");
        write(new File(d, "tray.png"), tray);
        JSONObject m = new JSONObject();
        m.put("id", safe(id));
        m.put("name", name);
        m.put("author", author);
        m.put("animated", animated);
        m.put("version", String.valueOf(System.currentTimeMillis()));
        m.put("stickers", new JSONArray());
        // meta.json is written last (in commit) so half-written packs are never served
        write(new File(d, "meta.tmp"), m.toString().getBytes("UTF-8"));
    }

    static synchronized void addSticker(Context c, String id, int idx, byte[] data, String emojis) throws Exception {
        File d = dir(c, id);
        File tmp = new File(d, "meta.tmp");
        if (!tmp.exists()) throw new IOException("Pack not started");
        JSONObject m = new JSONObject(new String(read(tmp), "UTF-8"));
        String fn = String.format("s%03d.webp", idx);
        write(new File(d, fn), data);
        JSONObject s = new JSONObject();
        s.put("file", fn);
        s.put("emojis", emojis == null || emojis.isEmpty() ? "😀" : emojis);
        m.getJSONArray("stickers").put(s);
        write(tmp, m.toString().getBytes("UTF-8"));
    }

    static synchronized JSONObject commit(Context c, String id) throws Exception {
        File d = dir(c, id);
        File tmp = new File(d, "meta.tmp");
        if (!tmp.exists()) throw new IOException("Pack not started");
        JSONObject m = new JSONObject(new String(read(tmp), "UTF-8"));
        int n = m.getJSONArray("stickers").length();
        if (n < 3) throw new IOException("WhatsApp needs at least 3 stickers");
        if (n > 30) throw new IOException("WhatsApp allows at most 30 stickers");
        File meta = new File(d, "meta.json");
        if (!tmp.renameTo(meta)) {
            write(meta, read(tmp));
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
        }
        return m;
    }

    static synchronized JSONObject meta(Context c, String id) {
        try {
            File f = new File(dir(c, id), "meta.json");
            if (!f.exists()) return null;
            return new JSONObject(new String(read(f), "UTF-8"));
        } catch (Exception e) {
            return null;
        }
    }

    static byte[] read(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    static void write(File f, byte[] data) throws IOException {
        try (FileOutputStream out = new FileOutputStream(f)) {
            out.write(data);
        }
    }

    static void deleteRecursive(File f) {
        if (!f.exists()) return;
        File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) deleteRecursive(x);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
