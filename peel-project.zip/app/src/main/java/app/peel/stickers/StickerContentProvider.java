package app.peel.stickers;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

/** Implements the WhatsApp sticker contract: metadata, stickers, and stickers_asset. */
public class StickerContentProvider extends ContentProvider {
    private static final int METADATA = 1, METADATA_ONE = 2, STICKERS = 3, ASSET = 4;
    private UriMatcher matcher;
    private String authority;

    @Override
    public boolean onCreate() {
        authority = getContext().getPackageName() + ".stickercontentprovider";
        matcher = new UriMatcher(UriMatcher.NO_MATCH);
        matcher.addURI(authority, "metadata", METADATA);
        matcher.addURI(authority, "metadata/*", METADATA_ONE);
        matcher.addURI(authority, "stickers/*", STICKERS);
        matcher.addURI(authority, "stickers_asset/*/*", ASSET);
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        Context c = getContext();
        switch (matcher.match(uri)) {
            case METADATA:
                return packs(c, StickerStore.ids(c), uri);
            case METADATA_ONE: {
                List<String> one = new java.util.ArrayList<>();
                one.add(uri.getLastPathSegment());
                return packs(c, one, uri);
            }
            case STICKERS:
                return stickers(c, uri.getLastPathSegment(), uri);
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }
    }

    private Cursor packs(Context c, List<String> ids, Uri uri) {
        MatrixCursor cur = new MatrixCursor(new String[]{
                "sticker_pack_identifier", "sticker_pack_name", "sticker_pack_publisher", "sticker_pack_icon",
                "android_play_store_link", "ios_app_download_link", "sticker_pack_publisher_email",
                "sticker_pack_publisher_website", "sticker_pack_privacy_policy_website",
                "sticker_pack_license_agreement_website", "image_data_version",
                "whatsapp_will_not_cache_stickers", "animated_sticker_pack"});
        for (String id : ids) {
            JSONObject m = StickerStore.meta(c, id);
            if (m == null) continue;
            cur.addRow(new Object[]{
                    m.optString("id"), m.optString("name"), m.optString("author"), "tray.png",
                    "", "", "", "", "", "",
                    m.optString("version", "1"), 0, m.optBoolean("animated") ? 1 : 0});
        }
        cur.setNotificationUri(c.getContentResolver(), uri);
        return cur;
    }

    private Cursor stickers(Context c, String id, Uri uri) {
        MatrixCursor cur = new MatrixCursor(new String[]{"sticker_file_name", "sticker_emoji", "sticker_accessibility_text"});
        JSONObject m = StickerStore.meta(c, id);
        if (m != null) {
            JSONArray a = m.optJSONArray("stickers");
            if (a != null) for (int i = 0; i < a.length(); i++) {
                JSONObject s = a.optJSONObject(i);
                if (s == null) continue;
                cur.addRow(new Object[]{s.optString("file"), s.optString("emojis"), "Sticker " + (i + 1)});
            }
        }
        cur.setNotificationUri(c.getContentResolver(), uri);
        return cur;
    }

    @Override
    public AssetFileDescriptor openAssetFile(Uri uri, String mode) throws FileNotFoundException {
        if (matcher.match(uri) != ASSET) throw new FileNotFoundException("Unknown URI: " + uri);
        List<String> seg = uri.getPathSegments();
        String id = seg.get(seg.size() - 2);
        String name = seg.get(seg.size() - 1);
        if (name.contains("/") || name.contains("..")) throw new FileNotFoundException("Bad name");
        File f = new File(StickerStore.dir(getContext(), id), name);
        if (!f.exists()) throw new FileNotFoundException(f.getName());
        return new AssetFileDescriptor(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY), 0,
                AssetFileDescriptor.UNKNOWN_LENGTH);
    }

    @Override
    public String getType(Uri uri) {
        switch (matcher.match(uri)) {
            case METADATA:
                return "vnd.android.cursor.dir/vnd." + authority + ".metadata";
            case METADATA_ONE:
                return "vnd.android.cursor.item/vnd." + authority + ".metadata";
            case STICKERS:
                return "vnd.android.cursor.dir/vnd." + authority + ".stickers";
            case ASSET:
                String n = uri.getLastPathSegment();
                return n != null && n.endsWith(".png") ? "image/png" : "image/webp";
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("Not supported");
    }
}
