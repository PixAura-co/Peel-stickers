package app.peel.stickers;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends Activity {
    private static final int REQ_FILES = 1, REQ_WA = 2;

    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private final ArrayList<String> tgEmojis = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose photos and videos"), REQ_FILES);
                } catch (Exception e) {
                    chooser = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "PeelNative");
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILES) {
            if (chooser != null) {
                chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                chooser = null;
            }
        } else if (req == REQ_WA) {
            if (res == RESULT_OK) {
                js("onPeelResult('ok','')");
            } else {
                String err = data != null ? data.getStringExtra("validation_error") : null;
                if (err != null && !err.isEmpty()) js("onPeelResult('error'," + JSONObject.quote(err) + ")");
                else js("onPeelResult('cancel','')");
            }
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.peelBack?window.peelBack():false)", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private static byte[] b64(String s) {
        return Base64.decode(s, Base64.DEFAULT);
    }

    /** Methods return "" on success or an error message. They never throw into the WebView. */
    public class Bridge {
        @JavascriptInterface
        public String begin(String id, String name, String author, String trayB64, boolean animated) {
            try {
                StickerStore.begin(MainActivity.this, id, name, author, b64(trayB64), animated);
                return "";
            } catch (Throwable t) {
                return String.valueOf(t.getMessage());
            }
        }

        @JavascriptInterface
        public String addSticker(String id, int idx, String dataB64, String emojis) {
            try {
                StickerStore.addSticker(MainActivity.this, id, idx, b64(dataB64), emojis);
                return "";
            } catch (Throwable t) {
                return String.valueOf(t.getMessage());
            }
        }

        /** Finishes the pack and opens WhatsApp's own "Add to my stickers" screen. */
        @JavascriptInterface
        public String commit(final String id) {
            try {
                final JSONObject m = StickerStore.commit(MainActivity.this, id);
                runOnUiThread(() -> {
                    Intent i = new Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK");
                    i.putExtra("sticker_pack_id", m.optString("id"));
                    i.putExtra("sticker_pack_authority", getPackageName() + ".stickercontentprovider");
                    i.putExtra("sticker_pack_name", m.optString("name"));
                    try {
                        startActivityForResult(i, REQ_WA);
                    } catch (ActivityNotFoundException e) {
                        js("onPeelResult('missing','WhatsApp')");
                    }
                });
                return "";
            } catch (Throwable t) {
                return String.valueOf(t.getMessage());
            }
        }

        @JavascriptInterface
        public String tgBegin() {
            try {
                File d = new File(getCacheDir(), "tg");
                StickerStore.deleteRecursive(d);
                //noinspection ResultOfMethodCallIgnored
                d.mkdirs();
                tgEmojis.clear();
                return "";
            } catch (Throwable t) {
                return String.valueOf(t.getMessage());
            }
        }

        @JavascriptInterface
        public String tgAdd(int idx, String dataB64, String ext, String emoji) {
            try {
                File f = new File(new File(getCacheDir(), "tg"), String.format("%03d.%s", idx, ext.replaceAll("[^a-z0-9]", "")));
                StickerStore.write(f, b64(dataB64));
                tgEmojis.add(emoji == null || emoji.isEmpty() ? "😀" : emoji);
                return "";
            } catch (Throwable t) {
                return String.valueOf(t.getMessage());
            }
        }

        /** Opens Telegram's sticker importer. Falls back to a share sheet if Telegram lacks it. */
        @JavascriptInterface
        public String tgSend(final boolean video) {
            try {
                File[] fs = new File(getCacheDir(), "tg").listFiles();
                if (fs == null || fs.length == 0) return "No stickers to send";
                Arrays.sort(fs);
                final ArrayList<Uri> uris = new ArrayList<>();
                for (File f : fs) uris.add(FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f));
                final ArrayList<String> emo = new ArrayList<>(tgEmojis);
                runOnUiThread(() -> {
                    Intent i = new Intent("org.telegram.messenger.CREATE_STICKER_PACK");
                    i.setType(video ? "video/webm" : "image/*");
                    i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    i.putStringArrayListExtra("STICKER_EMOJIS", emo);
                    i.putExtra("IMPORTER", "Peel");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    i.setClipData(clip(uris));
                    try {
                        startActivity(i);
                        js("onPeelResult('tg','')");
                    } catch (ActivityNotFoundException e) {
                        Intent s = new Intent(Intent.ACTION_SEND_MULTIPLE);
                        s.setType("*/*");
                        s.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                        s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        s.setClipData(clip(uris));
                        try {
                            startActivity(Intent.createChooser(s, "Send stickers to Telegram"));
                            js("onPeelResult('tgshare','')");
                        } catch (Exception x) {
                            js("onPeelResult('missing','Telegram')");
                        }
                    }
                });
                return "";
            } catch (Throwable t) {
                return String.valueOf(t.getMessage());
            }
        }
    }

    private static ClipData clip(ArrayList<Uri> uris) {
        ClipData cd = ClipData.newRawUri("stickers", uris.get(0));
        for (int k = 1; k < uris.size(); k++) cd.addItem(new ClipData.Item(uris.get(k)));
        return cd;
    }
}
